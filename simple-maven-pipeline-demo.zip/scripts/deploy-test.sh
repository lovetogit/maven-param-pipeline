#!/bin/bash
echo '🧪 Deploying to Testing Environment'
